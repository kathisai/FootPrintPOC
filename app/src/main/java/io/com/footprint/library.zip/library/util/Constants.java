package io.com.footprint.library.util;

/**
 * Created by yaroslav on 8/3/17.
 */

public class Constants {
    public static final float VIEW_SCALE_FACTOR = .7f;
    public static final long DURATION_500 = 500;
}
